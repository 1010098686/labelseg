# Labelseg
labelseg is a tool for annotating medical images.